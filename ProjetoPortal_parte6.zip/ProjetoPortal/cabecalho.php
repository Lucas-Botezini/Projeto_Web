<?php
    include("conecta.php");
    $sql_cat = "SELECT * FROM `categorias`";
    $res_cat = $link->query($sql_cat);
    $db = mysqli_connect("localhost", "root", "", "banco_portal");
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/style.css">
    <title>Portal do Egresso</title>
</head>
<body>

  <header>
    <nav class="nav-top">
      <a href="index.php">
        <img class="logo" src="img/logo.png" alt="png">
      </a>
      <ul>
        <?php
        while($dados = mysqli_fetch_array($res_cat)){
        ?>
          <li class="nav-item-box">
            <a class="nav-item" href="paginas.php?id_cat='<?php echo $dados['id_cat'];?>'"><?php echo $dados['nome_cat']; ?></a>
          </li>
        <?php
        }
        ?>          
      </ul>
         
      <a href="admin/index.php" class="nav-item">Login</a>
                
    </nav>
    </header>