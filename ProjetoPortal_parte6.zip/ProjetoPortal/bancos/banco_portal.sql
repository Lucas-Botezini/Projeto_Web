-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 12-Dez-2022 às 15:59
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `banco_portal`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categorias`
--

CREATE TABLE `categorias` (
  `id_cat` int(11) NOT NULL,
  `nome_cat` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `categorias`
--

INSERT INTO `categorias` (`id_cat`, `nome_cat`) VALUES
(1, 'Informatica'),
(2, 'Administracao'),
(5, 'Cabô as aula'),
(6, 'Pimbada'),
(7, 'Música');

-- --------------------------------------------------------

--
-- Estrutura da tabela `fotos`
--

CREATE TABLE `fotos` (
  `id_foto` int(11) NOT NULL,
  `filename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `fotos`
--

INSERT INTO `fotos` (`id_foto`, `filename`) VALUES
(32, 'info.png'),
(33, 'mh-3.jpg'),
(34, 'memes-meme.gif'),
(35, 'homem-escala-arvore-mais-alta-da-amazonia.jpg'),
(36, 'memes-meme.gif');

-- --------------------------------------------------------

--
-- Estrutura da tabela `paginas`
--

CREATE TABLE `paginas` (
  `id` int(11) NOT NULL,
  `titulo` varchar(60) NOT NULL,
  `texto` text NOT NULL,
  `id_cat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `paginas`
--

INSERT INTO `paginas` (`id`, `titulo`, `texto`, `id_cat`) VALUES
(1, 'Técnico em Informática', '<h2>Perfil profissional de conclusão\r\n</h2>Instala sistemas operacionais, aplicativos e periféricos para desktop e servidores. Desenvolve e documenta aplicações para desktop com acesso a web e a banco de dados. Realiza manutenção de computadores de uso geral. Instala e configura redes de computadores locais de pequeno porte.\r\n\r\nModalidade: Integrado (3 anos)\r\n\r\nRequisitos: Ensino Fundamental Completo\r\n\r\nTurno: Manhã e Tarde (tarde uma vez por semana)\r\n\r\nPPC – Técnico em Informática (a partir de 2019)\r\n\r\nTrata-se da versão atualizada do Projeto Pedagógico do Curso Técnico em Informática Integrado ao Ensino Médio (0172653), forma de oferta integrado, Campus Avançado Barracão, aprovado pelo Parecer Consepe 25/2017,cuja periodicidade da apuração dos resultados do processo avaliativo (p. 16) foi alterada de bimestral para trimestral, conforme autorização emitida pela Pró-reitoria de Ensino em 19 de outubro de 2018 (0049366). Nenhuma outra alteração foi efetuada.', 1),
(2, 'Técnico em Administração', 'Perfil profissional de conclusão\r\n\r\nExecuta operações administrativas relativas a protocolos e arquivos, confecção e expedição de documentos e controle de estoques. Aplica conceitos e modelos de gestão em funções administrativas. Opera sistemas de informações gerenciais de pessoal e de materiais.\r\n\r\nModalidade: Integrado (4 anos)\r\n\r\nRequisitos: Ensino Fundamental Completo\r\n\r\nTurno: Manhã\r\n\r\nPlano Pedagógico do Curso Técnico em Administração integrado ao Ensino Médio:\r\n\r\nPPC – Técnico em Administração (a partir de 2019)\r\n\r\nTrata-se da versão atualizada do Projeto Pedagógico do Curso Técnico em Administração Integrado ao Ensino Médio (0172911), forma de oferta integrado, Campus Avançado Barracão, aprovado pelo Parecer Consepe de 16 de dezembro de 2014, cuja periodicidade da apuração dos resultados do processo avaliativo (p. 87) foi alterada de bimestral para trimestral, conforme autorização emitida pela Pró-reitoria de Ensino em 19 de outubro de 2018 (0049506). Nenhuma outra alteração foi efetuada.', 2),
(3, 'Vambora da scola', '<img src=\'./img/memes-meme.gif\'>', 5),
(4, 'Pimbada música', '<img src=\'./img/pimbada-violenta.gif\'>', 6),
(5, 'Música | Pimbada', '<iframe width=\"110\" height=\"200\" src=\"https://www.myinstants.com/instant/pimbada-violenta-92091/embed/\" frameborder=\"0\" scrolling=\"no\"></iframe>', 7);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `user` varchar(40) NOT NULL,
  `pwd` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id`, `user`, `pwd`) VALUES
(1, 'lucas', '12345'),
(2, 'willian', '123');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id_cat`);

--
-- Índices para tabela `fotos`
--
ALTER TABLE `fotos`
  ADD PRIMARY KEY (`id_foto`);

--
-- Índices para tabela `paginas`
--
ALTER TABLE `paginas`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id_cat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `fotos`
--
ALTER TABLE `fotos`
  MODIFY `id_foto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de tabela `paginas`
--
ALTER TABLE `paginas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
