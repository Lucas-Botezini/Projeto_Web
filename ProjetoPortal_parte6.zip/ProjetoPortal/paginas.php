<?php
  
  $id_cat=$_GET['id_cat'];
  include("conecta.php");
  
  $sql = "SELECT * FROM `paginas` WHERE `id_cat`=$id_cat";
  $res = $link->query($sql);
  
  include("cabecalho.php");
  echo "<main class='paginas'>";

  while($dados = mysqli_fetch_array($res)){

  ?>
    <h1><?php echo $dados['titulo'];?></h1>
            
    <p><?php echo $dados['texto']; ?></p>
  <?php
  }
  ?>
  </main>;
</body>
</html>