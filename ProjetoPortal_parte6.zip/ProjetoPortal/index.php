

    <?php
    include("cabecalho.php");
    ?>
    <main class="container">
        <h1>
            Bem vindo ao Site de Egressos do IFPR de Barracão!
        </h1>
        <section class="img-container">
            <picture class="img-box">
                <a href="info.html" class="img-info">
                    <lord-icon
                        class="img"
                        src="https://cdn.lordicon.com/zlyxhzar.json"
                        trigger="morph"
                        style="width:200px;height:200px">
                    </lord-icon>
                </a>
            </picture>
            <picture class="img-box">
                <a href="adm.html" class="img-adm">
                    <lord-icon
                        class="img"
                        src="https://cdn.lordicon.com/qvbrkejx.json"
                        trigger="morph"
                        style="width:150px;height:150px">
                    </lord-icon>
                </a>
            </picture>
        </section>
        <h2>Fotos adicionadas</h2>
        <div class="db-img">
            <?php
                $query = " select * from fotos ";
                $result = mysqli_query($db, $query);
        
                while ($data = mysqli_fetch_assoc($result)) {
            ?>
                <img class="db-item" src="admin/fotos/image/<?php echo $data['filename']; ?>">
        
            <?php
                }
            ?>
            
        </div>
    </main>
    <script src="https://cdn.lordicon.com/qjzruarw.js"></script> <!-- BOOK -->
    <script src="https://cdn.lordicon.com/qjzruarw.js"></script> <!-- CODE -->
</body>
</html>