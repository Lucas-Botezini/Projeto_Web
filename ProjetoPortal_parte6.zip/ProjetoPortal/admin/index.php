<?php
    include("../conecta.php");
    header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/admin_style.css">
    <title>ADMIN | LOGIN</title>
</head>
<body>
    <form action="index.php" method="POST" class="form">
        <h1>LOGIN</h1>
        <section class="main-section">
            <div id="typing-container">
                <input type="text" id="email" class="typing-box" name="username" placeholder="Username" autocomplete="off" required>
            </div>
            <div id="typing-container">
                <input type="password" id="password" class="typing-box" name="password" placeholder="Password" autocomplete="off" required>
            </div>
            <button class="btn-login" type="submit">Entrar</button>
        </section>
    </form>

    <?php

        // Limpa os campos para não exibir mensagem de erro

        if (isset($_POST['username'])) {
            $user = $_POST['username'];
        } else {
            $user = "";
        }
    
        if (isset($_POST['password'])) {
            $password = $_POST['password'];
        } else {
            $password = "";
        }

        //Faz a consulta do tabela usuário e faz as comparações

        $consultaUsuario = "SELECT * FROM `usuario` WHERE user = '$user' AND pwd = '$password'";
        $usuarioResult = $link -> query($consultaUsuario);

        if (mysqli_num_rows($usuarioResult) > 0) { //Se existir uma linha com o cadastro
            header('Location: main.php');
        } else {
            if (isset($_POST['username'])) { //Se não existir
    ?>
                <script>
                    alert("Os dados não conferem! Tente novamente!");
                </script>

    <?php
            }
        }

    ?>

</body>
</html>