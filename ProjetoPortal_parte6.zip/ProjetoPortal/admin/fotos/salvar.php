<?php


    $sql_salvar="UPDATE `fotos` SET `titulo_foto`='$texto' WHERE `id_foto`='$id'";

    $res_salvar = $link->query($sql_salvar);
    
    if(!$res_salvar){
        ?>
        <script>
            alert("Erro ao salvar alteração!");
        </script>   
        <?php
    }

    else {
        ?>
        <script>
            alert("Alteração Salva com Sucesso!");
        </script>   
        <?php
    
    }
    header("refresh: 0.5; url=index.php");


?>
