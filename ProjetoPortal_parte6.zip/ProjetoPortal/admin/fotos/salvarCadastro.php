<?php
    $sql_novoCad = "INSERT INTO `fotos` VALUE ('', '$texto', '','')";

    $res_novoCad = $link->query($sql_novoCad);

    if(!$res_novoCad){
        ?>
        <script>
            alert("Erro ao adicionar foto!");
        </script>
        <?php
    }

    else{
        ?>
        <script>
            alert("Foto adicionada com Sucesso!");
        </script>
    <?php
    }

    header("refresh: 0.5; url=index.php");
    
?>