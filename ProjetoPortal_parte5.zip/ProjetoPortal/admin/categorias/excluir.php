<?php
    $sql_del = "DELETE FROM `categorias` WHERE `id_cat` = '$id'";
    $res_del=$link->query($sql_del);

    if(!$res_del){
        ?>
        <script>
            alert("Erro ao Excluir Dados!");
        </script>

        <?php
    }   

    else {
        ?>
        <script>
            alert("Dados Excluidos com Sucesso!");
        </script>
    <?php
    }
    header("refresh: 0.5; url=index.php");
?>