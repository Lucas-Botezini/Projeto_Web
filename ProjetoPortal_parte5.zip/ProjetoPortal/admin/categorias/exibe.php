<?php

    $sql_cat = "SELECT * FROM `categorias`";
    $res =$link->query($sql_cat);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Exibição das Tabelas</title>
</head>
<body>
    <main>
        <h1>Categorias</h1>

            <table border="1"> 
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Ações</th>
                </tr>
                <?php
                while ($dados = mysqli_fetch_array($res))  {
                ?>

                    <form action="index.php" method="POST">
                        <tr>
                            <td><?php echo $dados['id_cat']   ?></td>
                            <td><?php echo $dados['nome_cat']   ?></td>

                            <td>
                                <input type="hidden" name="id" value="<?php echo $dados['id_cat']?> ">
                                <input type="submit" name="acao" value="Editar">
                                <input type="submit" name="acao" value="Excluir">
                            </td>
                        </tr>
                    </form>
                <?php   
                }
                ?>

            </table>

            <form action="index.php" method="POST">
                <input type="submit" name="acao" value="Novo">
            </form>

    </main>
</body>
</html>