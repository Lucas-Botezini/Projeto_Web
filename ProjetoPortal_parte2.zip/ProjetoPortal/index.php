<?php
    include("conecta.php");
    $sql_cat = "SELECT * FROM `categorias`";
    $res_cat = $link->query($sql_cat);
    $db = mysqli_connect("localhost", "root", "", "banco_portal");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>Portal do Egresso</title>
</head>
<body>
    <header>

    </header>
    <main>
        <h1>
            Bem vindo ao Site de Egressos Do IFPR de Barracão!
        </h1>
        <section id="info">
            <picture><a href=""><img src="img/infoimg.png" alt="Img de Info"></a></picture>
        </section>
        <section id="info">
            <picture><a href=""><img src="img/adm.svg" alt="Img de Info"></a></picture>
        </section>
        <nav>
            <ul>
                <?php
                    while($dados = mysqli_fetch_array($res_cat)){
                ?>
                <li>
                    <a href="navega/<?php echo $dados['nome_cat']; ?>.php"><?php echo $dados['nome_cat']; ?></a>
                </li>
                <?php
                    }
                ?>
            </ul>
        </nav>
        <div>
            <?php
                $query = " select * from fotos ";
                $result = mysqli_query($db, $query);
        
                while ($data = mysqli_fetch_assoc($result)) {
            ?>
                <img src="admin/fotos/image/<?php echo $data['filename']; ?>">
        
            <?php
                }
            ?>
            
        </div>
    </main>
</body>
</html>