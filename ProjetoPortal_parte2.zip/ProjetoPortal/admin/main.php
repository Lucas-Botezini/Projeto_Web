<?php
    include("../conecta.php");
    header('Content-Type: text/html; charset=utf-8');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN | PANEL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Items | Database</h1>
    <main class="main-section">
        <table>
            <tr>
                <th><strong>ITEMS</strong></th>
            </tr>
            <tr>
                <td><a class="table-item" href="categorias/index.php">Categoria</a></td>
            </tr>
            <tr>
                <td><a class="table-item" href="fotos/index.php">Fotos</a></td>
            </tr>
        </table>
    </main>
</body>
</html>