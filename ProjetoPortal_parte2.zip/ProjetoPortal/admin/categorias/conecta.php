<?php 

$host = "localhost";
$user = "root";
$pass = "";
$db = "banco_portal";

$link = mysqli_connect($host, $user, $pass, $db);

if(!$link)  {
    echo "Falha ao conectar com o banco".PHP_EOL;
    exit;
}