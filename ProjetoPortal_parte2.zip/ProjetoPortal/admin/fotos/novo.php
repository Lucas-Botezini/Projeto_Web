<html>
  <head>
      <meta charset="UTF-8">
      <link rel="stylesheet" href="css/estilo.css">
  <head>
  <body>

    <main>
        <h1>Fotos - Cadastro</h1>
       
            <table border="1">
                  <form action="index.php" method="POST">
                    <tr>
                        <td>
                          <input type="text" name="texto">
                        </td>
                        <td>
                          <input type="submit" name="acao" value="Cadastrar">
                        </td>
                    <tr>
                  </form> 
            </table>
    </main>
  <footer>
  </footer>
  </body>
</html>