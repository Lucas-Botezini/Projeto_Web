<?php

    $sql_foto = "SELECT * FROM `fotos`";
    $res =$link->query($sql_foto);

?>


<?php
    error_reporting(0);
    
    $msg = "";
    
    // If upload button is clicked ...
    if (isset($_POST['upload'])) {
    
        $filename = $_FILES["uploadfile"]["name"];
        $tempname = $_FILES["uploadfile"]["tmp_name"];
        $folder = "./image/" . $filename;
    
        $db = mysqli_connect("localhost", "root", "", "banco_portal");
    
        // Get all the submitted data from the form
        $sql = "INSERT INTO fotos (filename) VALUES ('$filename')";
    
        // Execute query
        mysqli_query($db, $sql);
    
        // Now let's move the uploaded image into the folder: image
        if (move_uploaded_file($tempname, $folder)) {
            echo "<h3>  Image uploaded successfully!</h3>";
        } else {
            echo "<h3>  Failed to upload image!</h3>";
        }
    }
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Exibição das Tabelas</title>
</head>
<body>
    <main>
        <h1>Fotos</h1>

            <table border="1"> 
                <tr>
                    <th>ID</th>
                    <th>Titulo</th>
                    <th>Ação</th>
                </tr>
                <?php
                while ($dados = mysqli_fetch_array($res))  {
                ?>

                    <form action="index.php" method="POST">
                        <tr>
                            <td><?php echo $dados['id_foto']   ?></td>
                            <td><?php echo $dados['filename']   ?></td>

                            <td>
                                <input type="hidden" name="id" value="<?php echo $dados['id_foto']?> ">
                                
                                <input type="submit" name="acao" value="Excluir">
                            </td>
                        </tr>
                    </form>
                <?php   
                }
                ?>

            </table>

            <div id="content">
                <form method="POST" action="" enctype="multipart/form-data">
            <div class="form-group">
                <input class="form-control" type="file" name="uploadfile" value="" />
            </div>
            <div class="form-group">
                <button class="btn btn-primary" type="submit" name="upload">UPLOAD</button>
            </div>




        </form>
        </div>
        <div id="display-image">
        <?php
            $query = " select * from fotos ";
            $result = mysqli_query($db, $query);
    
            while ($data = mysqli_fetch_assoc($result)) {
        ?>
            <img src="./image/<?php echo $data['filename']; ?>">
    
        <?php
            }
        ?>
    </div>

    </main>
</body>
</html>