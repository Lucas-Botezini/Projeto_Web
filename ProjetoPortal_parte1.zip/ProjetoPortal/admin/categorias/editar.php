<?php
  // Executa uma consulta
  $sql_editar="SELECT * FROM `categorias` WHERE `id_cat`='$id'";
  $res_editar=$link->query($sql_editar);

?>
<html>
  <head>
      <meta charset="UTF-8">
      
  <head>
  <body>

    <main>
        <h1>Categorias</h1>
       
            <table border="1">
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Ações</th>
                </tr>
                <?php
                while ($dados = mysqli_fetch_array($res_editar)) {
                ?>
                  <form action="index.php" method="POST">
                    <tr>
                        <td><?php echo $dados['id_cat'] ?></td>
                        <td><input type="text" name="texto" value="<?php echo $dados['nome_cat']?>"></td>
                        <td>
                          <input type="hidden" name="id" value="<?php echo $dados['id_cat']?>">
                          <input type="submit" name="acao" value="Salvar">
                        </td>
                    <tr>
                  </form> 
                <?php
                }
                ?>
            </table>
           
    </main>
  <footer>
  </footer>
  </body>
</html>