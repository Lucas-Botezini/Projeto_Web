<?php 
    include("conecta.php");

    if(isset($_POST['acao']))   {
        $acao = $_POST['acao'];

        if(isset($_POST['id'])) {
            $id = $_POST['id'];
        }
        if(isset($_POST['texto']))  {
            $texto = $_POST['texto'];
        }
    }   else {
        $acao = "Exibir";
    }

    if($acao == "Excluir")  {
        include("excluir.php");

    }  
    
    else if($acao == "Editar")   {
        include("editar.php");
    }   
    
    else if($acao == "Salvar")   {
        include("salvar.php");
    }

    else if($acao == "Novo"){
        include("novo.php");
    }

    else if($acao == "Cadastrar")   {
        include("salvarcadastro.php");
    }

    else{
        include("exibe.php");
    }



?>