<?php
    $sql_novoCad = "INSERT INTO `categorias` VALUE ('', '$texto')";

    $res_novoCad = $link->query($sql_novoCad);

    if(!$res_novoCad){
        ?>
        <script>
            alert("Erro ao adicionar categoria!");
        </script>
        <?php
    }

    else{
        ?>
        <script>
            alert("Categoria adicionada com Sucesso!");
        </script>
    <?php
    }

    header("refresh: 0.5; url=index.php");
    
?>